iosOverlay.js
===========

[Full documentation and examples/demos](http://taitems.github.com/iOS-Overlay/)
===========

**License type:** MIT/GPL/Do whatever you want just don't be a nozzle.